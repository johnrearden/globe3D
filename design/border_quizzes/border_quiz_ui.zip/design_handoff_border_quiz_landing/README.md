# Handoff: Border Quiz Landing Page (per-country)

## Overview
A **programmatic SEO landing page** for Terragotcha. One page per high-impact country at a URL
like `terragotcha.com/borders/france/`. The page poses a single quiz: **"Which countries border
[Country]?"** The visitor taps every country they believe shares a land border, then hits
**Check answer** to reveal how they did — a taste of the app that funnels to
`terragotcha.com`.

The page is **templated**: everything specific to the country (name, continent, area, the map
image, and the set of correct border answers + the distractor options) is data. The layout,
styling, and interaction are identical across all country pages.

This handoff redesigns the **desktop** layout (the old one stacked the mobile card in a narrow
center column, wasting the screen's flanks) and keeps the **mobile** layout as a single card.

## About the design files
`Border Quiz Landing.dc.html` is a **design reference built in HTML** — a prototype of the
intended look and behavior, **not production code to ship**. It runs in a bespoke preview
runtime (`support.js`) using a `.dc.html` component format; **do not ship `support.js`, the
`.dc.html` file, or `image-slot.js`**. Recreate the design in Terragotcha's real stack
(the site is Django-served — see the admin tab in the reference screenshots) using its existing
templates/components and the design tokens in `tokens/` + `styles.css`.

The `.dc.html` contains **both** the desktop and mobile layouts side by side on a design canvas
(two frames) — it is one responsive page, not two.

## Fidelity
**High-fidelity.** Colors, type, spacing, radii, shadows, and interaction states are specified
below and should be reproduced precisely, mapped onto the codebase's existing tokens/components.

## Layout

### Desktop (designed at 1920px wide; fluid — see notes)
Full-bleed navy radial-gradient background. Content in a padded container (`52px 72px 48px`).

1. **Top bar** — Terragotcha wordmark (left); ghost amber pill "Explore the 3D globe" → `terragotcha.com` (right).
2. **Hero — two columns**, `grid-template-columns: 960px 1fr; gap: 64px; align-items: stretch`:
   - **Left — map hero:** tall panel (`min-height: 540px`), `border-radius: 20px`, hairline
     border, drop shadow, and a soft amber radial glow behind the image (pulsing, `lp-glow`
     3.5s). The country map image fills it (`object-fit: cover`). A bottom gradient scrim carries
     a caption: eyebrow continent ("EUROPE"), big country name ("France", Fredoka 34px), and a
     stat row (area `551,695 km²`; a challenge prompt "How many neighbours can you name?").
   - **Right — interaction:** amber eyebrow "BORDER CHALLENGE"; H1 "Which countries border
     France?" (Fredoka 600, 38px); one-line description; hairline divider; an instruction row
     ("SELECT THE NEIGHBOURS" + the live counter chip); the **answer grid** (3 columns,
     `gap: 11px`); then the actions row (**Check answer** button + result line).
3. **CTA band** — full-width panel: "Reclaim your brain." + subline (left), amber
   "Visit Terragotcha.com" pill (right).
4. **Footer** — centered "Privacy Policy · © 2026 Terragotcha".

### Mobile (single card, ~400–440px)
Stacked in one rounded card: header (H1 + inline wordmark), description, map (220px tall, same
glow), instruction + counter row, **2-column** answer grid, Check answer + result, a compact
"Reclaim your brain" CTA card, footer. This mirrors the current production mobile page — keep it.

## Interaction & behavior
- **Select:** tapping a country toggles it. Selected = amber fill (`rgba(245,158,75,.16)`),
  amber border (`rgba(245,158,75,.62)`), text `#ffe4c4`, and a filled amber `check-circle` icon.
  Unselected = faint (`bg rgba(255,255,255,.03)`, border `rgba(255,255,255,.1)`, text `#dfe7ef`).
- **Counter chip** (top-right of the grid): while playing shows **"N selected"**; after checking
  shows **"N correct"**.
- **Check answer button:** disabled/greyed until ≥1 selection; enabled = amber gradient pill.
  After checking it becomes a neutral **"Try again"** button that resets selections.
- **On check — reveal states** (grid becomes read-only):
  - Correct + selected → green (`bg rgba(46,160,103,.16)`, border `rgba(64,196,128,.62)`, text
    `#bff0d2`, bold check icon `#6fe3a0`).
  - Correct + missed → faint green (`bg rgba(46,160,103,.06)`, border `rgba(64,196,128,.32)`,
    text `#7fb79a`, `ph ph-plus` icon).
  - Wrong + selected → red (`bg rgba(196,60,60,.16)`, border `rgba(228,90,90,.6)`, text
    `#f3c4c4`, bold x icon `#f08a8a`).
  - Not correct, not selected → dimmed text `#5c708a`.
- **Result line** (after check): "Perfect — every border found!" (green) or
  "N correct · N wrong" (amber if nearly all right, else red).

### ⚠️ Critical rule: never reveal the number of correct answers
The quiz must **not** tell the user how many countries to select — that gives the answer away and
makes it too easy. **No "of 8" anywhere.** The counter shows a bare count ("3 selected" /
"5 correct"), the result line never states the total, and the map caption uses a prompt
("How many neighbours can you name?") rather than a border count. Preserve this in production —
do not add a "0/8" style progress indicator.

## Motion
- Entrance: `lp-fade` — opacity 0→1, `translateY(10px)→0`, ~0.5–0.6s, staggered per section.
- Map glow: `lp-glow` — opacity 0.5↔0.85, 3.5s ease-in-out, infinite.
- All transitions `cubic-bezier(0.4,0,0.2,1)`. Gentle, never bouncy (system rule).

## Data model (per country page)
Each page is generated from:
- `name` (e.g. "France"), `continent` ("Europe"), `area` ("551,695 km²").
- `mapImage` — a static render of the country highlighted among its neighbours (from the app).
- `options[]` — the list of country names shown as buttons (correct neighbours **plus**
  distractors), in display order.
- `correct[]` — the subset of `options` that actually border the country.

**France reference data used in the prototype:**
- options (14): Spain, Andorra, San Marino, Netherlands, Switzerland, Austria, Liechtenstein,
  Monaco, Belgium, United Kingdom, Vatican, Germany, Italy, Luxembourg.
- correct (8): Spain, Andorra, Monaco, Italy, Switzerland, Germany, Luxembourg, Belgium.
  *(Sovereign land neighbours. Confirm the microstate policy — Monaco/Andorra included, San
  Marino/Vatican are distractors — matches your content model.)*

## State
Client-side only, no backend needed for the quiz itself: `selected` (set of country names) and
`checked` (boolean). "Try again" clears both. No score is persisted.

## Design tokens (source of truth: `tokens/` + `styles.css`)
- **Background:** navy radial gradient — top `#123452`, mid `#0a1c30` (`--navy-800`), base
  `#06121f` (`--navy-900`).
- **Accent (amber):** `#f59e4b` (`--amber-500`); gradient `#f9b25f → #f59440`; light `#ffd9a8`.
  On-amber text `#3a2008`. This is the ONLY accent — vary lightness, no second hue.
- **Semantic (this page only):** success green `#6fe3a0` / borders `rgba(64,196,128,*)`; error
  red `#f08a8a` / borders `rgba(228,90,90,*)`. Confirm/promote to tokens if reused.
- **Text:** high `#eef2f6`/`#f6faff`, mid `#9db2c6`, low `#5c708a`.
- **Surfaces:** panels `rgba(6,18,31,.55)`, hairline borders `rgba(255,255,255,.08–.1)`.
- **Radius:** pill `999px` (buttons/chips), `16–20px` (cards/panels), `12px` (answer buttons).
- **Shadow:** float `0 8px 40px rgba(0,0,0,.28)`; amber button
  `0 8px 24px rgba(245,158,75,.4)` + `0 2px 0 rgba(255,255,255,.28) inset`.
- **Type:** **Fredoka** (wordmark, H1, numerals, button labels); **Archivo** (all UI/body).
  Uppercase labels use wide tracking (`.16–.22em`). Two families only.

## Assets
- **Icons — Phosphor** (`@phosphor-icons/web@2.1.1`, MIT): `globe-hemisphere-west`, `ruler`,
  `path`, `map-pin`, `check-circle` (fill), `check`/`x`/`plus`. Use the app's existing setup.
- **Fonts** — Fredoka + Archivo (Google Fonts); use the app's existing loading.
- **Map image** — the prototype uses a drag-drop image slot as a stand-in. Ship the real
  per-country map render (`object-fit: cover` inside the panel).

## Notes / open questions
- **Desktop width:** designed at 1920px. Make the real page fluid — cap the content at a sensible
  max-width (~1600–1760px) and center it; let the two-column hero collapse to a single column
  below ~900px (→ the mobile layout). The 960px map column is a ratio, not a hard pixel.
- Confirm the microstate answer policy noted above.
- Green/red are new semantic colors outside the single-amber system — confirm before reuse.

## Files in this bundle
- `Border Quiz Landing.dc.html` — the prototype (reference only; do not ship).
- `styles.css` + `tokens/*.css` — the real Terragotcha design tokens (source of truth).
- `readme.md` — full Terragotcha design-system readme (voice, brand, iconography).
