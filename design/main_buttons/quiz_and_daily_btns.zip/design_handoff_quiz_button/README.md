# Handoff: Quiz Button (primary CTA) + Daily Challenge button

## Overview
The **Quiz Button** is the app's primary call-to-action — the main thing a user does on
Terragotcha is start a geography quiz. It floats over the live three.js globe. Beside it
sits a **secondary "Daily Challenge"** entry point, deliberately less prominent and in a
distinct purple so it reads as a different activity.

Both buttons are responsive and change placement by breakpoint:

- **Desktop:** the cluster sits **top-left**. The amber Quiz button is large and striking and
  shows the quiz scope ("Countries · Flags · Capitals") on a second line inside the pill; the
  purple Daily Challenge pill sits directly **below** it, aligned to the same left edge.
- **Mobile:** the cluster sits **bottom-right**. The amber Quiz button is a simple single-line
  pill; the purple Daily Challenge pill sits **above** it, aligned to the same right edge.

Tapping "Give me a quiz" opens the quiz-mode picker modal (a separate design — the
Countries/Flags/Capitals customization lives there, NOT on the button). Tapping "Daily
challenge" launches the day's fixed challenge.

## About the Design Files
The files in this bundle are **design references created in HTML** — a prototype showing the
intended look and behavior, **not production code to copy directly**. `Quiz Button.dc.html`
is a "Design Component" that runs in a bespoke preview runtime (`support.js`); do **not** ship
`support.js` or the `.dc.html` format.

Your task is to **recreate this design in the Terragotcha app's existing environment** using its
established patterns (the app is a mobile-first geography quiz built on a three.js 3D globe).
Implement the buttons as overlay UI rendered above the globe canvas. If the relevant part of the
codebase has no established UI framework yet, choose the most appropriate one for the project.

The `.dc.html` file contains **both** the mobile and desktop layouts side by side on a design
canvas (two device frames) for reference — it is one responsive component, not two.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, radii, shadows, and interaction
states are specified below and should be reproduced precisely, mapped onto the codebase's
existing tokens/components where they exist.

## Screens / Views

### Shared anatomy
Two buttons, same component, different placement per breakpoint. The globe renders full-bleed
behind everything; keep the buttons clear of the globe's visual center.

---

### Button 1 — Quiz (primary, amber)

**Purpose:** open the quiz-mode picker modal.

**Desktop treatment** (large, two-line):
- Shape: pill, `border-radius: 999px`. Padding `15px 28px 15px 22px`.
- Background: linear-gradient `180deg, #f9b25f → #f59440`.
- Shadow: `0 10px 30px rgba(245,158,75,.42)`, plus top inner highlight `0 2px 0 rgba(255,255,255,.30) inset`.
- Leading icon badge: 44×44px circle, `background: rgba(58,32,8,.16)`, containing a Phosphor
  **fill** `globe-hemisphere-west` icon, 25px, color `#3a2008`.
- Text block (column, `line-height:1`):
  - Title: **"Give me a quiz"** — Fredoka 600, 24px, letter-spacing −0.01em, color `#321a06`.
  - Subtitle: **"Countries · Flags · Capitals"** — Archivo 600, 10.5px, UPPERCASE,
    letter-spacing 0.13em, color `rgba(58,26,6,.62)`, `margin-top: 6px`. (Static label — it
    advertises the quiz scopes; it is NOT an interactive selector.)
- Behind the pill: an animated amber glow — a radial-gradient circle
  `radial-gradient(circle, rgba(245,158,75,.34), rgba(245,158,75,0) 68%)`, ~340×170px, centered
  on the pill, `pointer-events:none`, pulsing via the `qb-glow` keyframes (see Interactions).

**Mobile treatment** (compact, single-line):
- Shape: pill, padding `15px 22px`.
- Same amber gradient + inner highlight; shadow `0 8px 24px rgba(245,158,75,.40)`.
- Inline icon (no badge): Phosphor fill `globe-hemisphere-west`, 21px, `#3a2008`, `gap:10px`.
- Label: **"Give me a quiz"** — Fredoka 600, 17px, color `#3a2008`.
- Same pulsing amber glow behind it (~120×120px circle, `rgba(245,158,75,.42)` core).

**Hover (both):** `transform: translateY(-2px)` and a deeper/larger amber shadow.
**Active (both):** `translateY(0)` with a reduced shadow.

---

### Button 2 — Daily Challenge (secondary, purple)

**Purpose:** launch the day's fixed daily challenge. Intentionally **lower visual weight** than
the Quiz button — it's a translucent, bordered "ghost" pill, no glow, no gradient fill.

- Shape: pill, `border-radius: 999px`.
  - Desktop padding `12px 20px`; mobile padding `10px 16px`.
- Background: `rgba(124,108,232,.16)` (translucent violet) with `backdrop-filter: blur(10px)`.
- Border: `1px solid rgba(140,124,240,.42)`.
- Shadow: `0 4px 18px rgba(0,0,0,.28)` (desktop) / `0 4px 16px rgba(0,0,0,.30)` (mobile).
- Icon: Phosphor **fill** `calendar-dots`, 19px desktop / 17px mobile, color `#b6a7f5`. `gap:10px` / `8px`.
- Label: **"Daily challenge"** — Fredoka 500, 15px desktop / 14px mobile, letter-spacing −0.01em,
  color `#d8cffb`.
- **Hover:** background `rgba(124,108,232,.26)`, border `rgba(160,144,248,.6)`.
- **Active:** `transform: translateY(1px)`.

> **Purple is a new accent.** The Terragotcha system is single-accent (amber). This violet is
> introduced here to differentiate the secondary daily-challenge action from the primary quiz
> action. **Promote it to a named token (e.g. `--violet-400: #8c7cf0`) and confirm with design**
> before reusing elsewhere.

---

### Layout & placement

**Desktop** (cluster anchored top-left, `left: 34px; top: 32px`):
- Vertical stack: Quiz button, then Daily Challenge button **below** it with `margin-top: 15px`.
- Both pills are left-aligned to the same edge (cluster's left edge).
- Entrance: the whole cluster fades up via `qb-fade` (0.6s).

**Mobile** (cluster anchored bottom-right, `right: 18px; bottom: 18px`):
- Flex column, `align-items: flex-end`, `gap: 12px`.
- Order top→bottom: Daily Challenge button, then Quiz button (so Quiz hugs the bottom-right corner).
- Both pills are right-aligned to the same edge.
- For context, a settings button (44px circle, `rgba(6,18,31,.74)`, gear-six icon) sits at
  bottom-left — that's existing chrome, not part of this deliverable.

## Interactions & Behavior
- **Quiz button → open quiz-mode picker modal.** In the prototype the handler is a no-op stub
  (`start`). Wire it to the modal that owns Countries/Flags/Capitals customization.
- **Daily Challenge button → launch the daily challenge** for the current date.
- **Hover/active states** as specified per button above. Transition:
  `all .18s cubic-bezier(.4,0,.2,1)` (the design-system `--ease-soft`).
- **Amber glow pulse** (`qb-glow`, primary button only):
  `0%,100% { opacity:.45; scale(1) } 50% { opacity:.8; scale(1.08) }`, 3.5s ease-in-out,
  infinite. (Matches the system's `--dur-glow` glow pulse.) Translate is `-50%,-50%` to keep it
  centered.
- **Cluster entrance** (`qb-fade`): opacity 0→1, `translateY(8px)→0`, 0.6s `cubic-bezier(.4,0,.2,1)`.
- The globe spin animation in the prototype (`qb-spin`) is just the static `globe.png` backdrop
  standing in for the real three.js globe — **ignore it**; the live globe owns that.
- **Motion note:** keep all motion gentle/continuous, never bouncy (system rule).

## State Management
- Effectively stateless. The prototype's only handler (`start`) is a no-op placeholder.
- Real app needs: an open-quiz-modal action, and a launch-daily-challenge action (with the
  current date / challenge id). No local UI state lives on the buttons themselves.

## Design Tokens
Colors:
- Amber gradient: `#f9b25f` → `#f59440` (primary action). Amber accent family: `--amber-500 #f59e4b`,
  `--amber-300 #ffd9a8`, `--amber-700 #c96a1f`.
- On-amber text/icon: `#3a2008` / `#321a06`; amber subtitle: `rgba(58,26,6,.62)`.
- Amber glow core: `rgba(245,158,75,.34–.42)`.
- Violet (Daily Challenge, NEW): fill `rgba(124,108,232,.16→.26)`, border `rgba(140,124,240,.42)` →
  hover `rgba(160,144,248,.6)`, icon `#b6a7f5`, label `#d8cffb`. Suggested base `#8c7cf0`.
- Navy surfaces (backdrop / settings chrome): `--navy-900 #06121f`, `--navy-800 #0a1c30`,
  `--navy-700 #102a44`.

Radius: pill `999px` (buttons), device frames `42px` mobile / `18px` desktop (prototype chrome only).

Shadow: amber `0 8–10px 24–30px rgba(245,158,75,.40–.42)` + `0 2px 0 rgba(255,255,255,.28–.30) inset`;
violet `0 4px 16–18px rgba(0,0,0,.28–.30)`.

Typography:
- **Fredoka** (display) — button titles/labels: 600 for "Give me a quiz" (24px desktop / 17px mobile),
  500 for "Daily challenge" (15/14px).
- **Archivo** (UI) — the uppercase scope subtitle: 600, 10.5px, tracking 0.13em.

Motion: ease `cubic-bezier(0.4,0,0.2,1)`; glow pulse 3.5s; entrance 0.6s.

## Assets
- **Icons: Phosphor** (`@phosphor-icons/web`, MIT) — `ph-fill ph-globe-hemisphere-west`,
  `ph-fill ph-calendar-dots`, `ph-fill ph-gear-six`. Use the codebase's existing Phosphor setup.
- **`assets/globe.png`** in the prototype is a stand-in for the live three.js globe — **do not
  ship it**; the real globe renders behind the buttons.
- **Fonts:** Fredoka + Archivo (Google Fonts) — use the app's existing font setup.

## Files
- `Quiz Button.dc.html` — the prototype (reference only; runs on `support.js`, do not ship).
  Contains BOTH the mobile and desktop layouts side by side.
- `styles.css` + `tokens/*.css` — the real Terragotcha design system (source of truth for tokens).
- `readme.md` — the full Terragotcha design-system readme (voice, brand, iconography rules).
