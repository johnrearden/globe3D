# Handoff: Daily Challenge Popup

## Overview
A modal/bottom-sheet prompt that appears **after the landing/loading overlay fades out and
the 3D globe begins spinning**. It invites the user into the day's timed quiz. It overlays
the live globe screen and dismisses on either action.

## About the Design Files
The files here are **design references created in HTML** — a prototype of the intended look
and behavior, **not** production code to ship directly. Recreate this in the app's existing
front-end (the three.js / web UI that renders the globe), using its established patterns.
The popup should mount as an overlay layer above the globe canvas.

## Fidelity
**High-fidelity.** Exact colors, type, spacing, and motion are specified. Reproduce it
faithfully. Authored for a ~392px-wide portrait viewport — scale proportionally to the real
device width. The sheet is anchored to the bottom with equal side insets.

## Design tokens
This handoff bundles the **Terragotcha Design System** (`styles.css` + `tokens/`). Use those
CSS custom properties rather than hardcoding values. Key ones used here:
- Surface: `--navy-800` #0a1c30, gradient `--bg-gradient`
- Accent: `--amber-500` #f59e4b (+ `--amber-600` #f59440 for the button gradient bottom)
- Text: `--text-high` #eef2f6, body `#9fb2c6`, muted `--text-low` #5c708a
- Type: `--font-display` Fredoka, `--font-ui` Archivo
- Radius pill `999px`; motion easing `cubic-bezier(.4,0,.2,1)`
- Icons: **Phosphor** (see design system iconography)

## Screen / View

### Daily Challenge popup (bottom sheet over the spinning globe)
- **Trigger**: fires once, after the loading overlay finishes fading and the globe starts spinning.
- **Behind it**: the live spinning globe on the navy `--bg-gradient` canvas. Top chrome remains
  visible: a "Quiz me" amber pill (top-left) and a settings gear icon button (top-right,
  Phosphor `ph-gear-six`).
- **The sheet**:
  - Anchored bottom, 14px side insets, 18px from bottom. Border-radius 22px.
  - Background `rgba(11,28,46,.74)` with `backdrop-filter: blur(14px)` (glass over the globe).
  - Border `1px solid rgba(255,255,255,.09)`; shadow `0 16px 44px rgba(0,0,0,.42)` plus a 1px
    top inset highlight `inset 0 -2px 0 rgba(255,255,255,.04)`.
  - Padding `18px 22px 15px`.
- **Contents (top to bottom):**
  1. **Heading** — "Up for today's challenge?"
     Fredoka 600, 21px, line-height 1.2, tracking −0.01em, color `--text-high`.
  2. **Body** — two lines (explicit `<br>`):
     "10 questions against the world …" / "Can't stop, I'm being timed"
     Archivo 400, 13.5px, line-height 1.45, color `#9fb2c6`, margin-top 6px.
     (Note the space before the ellipsis on line 1.)
  3. **Primary button** — "Start today's challenge"
     Full-width pill, padding 12px, radius 999px.
     Background `linear-gradient(180deg,#f7a857,#f59440)`, text color `#311a06`,
     Fredoka 600, 15px. Shadow `0 8px 22px rgba(245,158,75,.34)`.
     Hover: `brightness(1.04)` + `translateY(-1px)`. Margin-top 16px.
  4. **Secondary** — "Maybe later"
     Centered text link, Archivo 500, 14.5px, color `#6f86a0`, hover → `#9fb2c6`.
     Margin-top 11px. (Intentionally larger relative to the button than a typical caption.)

## Interactions & Behavior
- **Entrance**: sheet slides up + fades — `opacity 0→1`, `translateY(28px)→0`, 0.6s,
  `cubic-bezier(.4,0,.2,1)`. Inner elements fade-up (`translateY(8px)→0`, 0.6s) staggered
  by 0.05s (heading .1s, body .15s, button .2s, secondary .25s).
- **Globe glow**: soft amber radial behind the globe pulses opacity .55↔.85 over 3.5s
  (matches the loading screen).
- **Primary tap** → start the timed daily quiz (10 questions). Dismiss the sheet.
- **"Maybe later" tap** → dismiss the sheet, return to the idle spinning globe.
- **Dismiss animation**: reverse the entrance (fade + slide down ~250–300ms), then unmount.

## State Management
- `showDailyChallenge: boolean` — set true when the loading overlay completes; false on either action.
- Show **once per day**: gate on a stored date key (e.g. `localStorage` last-shown date) so it
  doesn't reappear on every load.
- Starting the challenge hands off to the quiz flow (timed, 10 questions) — out of scope here.

## Assets
- `assets/globe.png` — globe image used in the mock (612×612, feathered transparent edge).
  At runtime, prefer the live three.js globe behind the sheet; the PNG is the design intent / fallback.
- Icons via Phosphor CDN (pinned): `@phosphor-icons/web@2.1.1`.

## Files
- `Daily Challenge.dc.html` — the HTML prototype (open in a browser to see it live, including
  entrance motion). The gray canvas around the phone frame is presentation scaffolding, not shipped.
- `styles.css` + `tokens/` — the design system tokens to implement against.
- `readme.md` — full design system guide (colors, type, motion, iconography).
