# Handoff: Quiz Results Modal

## Overview
The end-of-quiz **results modal** for Terragotcha. It appears, centered over the dimmed live
globe, when a timed quiz finishes. It shows the player's **score** (e.g. `7/10`) inside an
animated progress ring, an encouraging headline, the **time taken**, and actions to play
again, share, or return to the globe.

## About the Design Files
The files in this bundle are **design references created in HTML** — a prototype showing the
intended look and behavior, **not production code to copy directly**. `Quiz Results.dc.html`
is a "Design Component" that runs in a bespoke preview runtime (`support.js`); do **not** ship
`support.js` or the `.dc.html` format.

Your task is to **recreate this design in the Terragotcha app's existing environment** using
its established patterns and component libraries. The app is a mobile geography quiz built on a
three.js 3D globe; implement this as a modal/dialog rendered over the globe. If the relevant
part of the codebase has no established UI framework yet, choose the most appropriate one and
implement there.

`styles.css` + `tokens/` **are** the real design system and are the source of truth for colors,
type, and effects (or map them onto the codebase's existing tokens if equivalents exist).

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, radii, and interactions are all
specified below and present in the prototype. Recreate the UI pixel-perfectly using the
codebase's existing libraries and patterns. Exact hex/px values are given throughout.

---

## Screens / Views

### View: Quiz Results modal
A centered dialog over a dimmed, slightly blurred globe backdrop.

**Frame (reference only):** the prototype renders inside a 392 × 800 device frame (40px corner
radius) on a neutral backdrop. In the real app this is a full-screen overlay — **only the
modal + backdrop matter**, not the device frame.

#### Backdrop
- The globe (`assets/globe.png` in the prototype; the live three.js globe in-app) sits centered
  near the upper third, **blurred 3px at opacity 0.34**.
- Over it, a scrim: `background: rgba(6,18,31,0.62)` with `backdrop-filter: blur(2px)`.

#### Modal card
- Centered: `left:50%; top:50%; transform:translate(-50%,-50%)`.
- Width **332px**, padding `28px 26px 22px`, `border-radius: 26px`.
- Background `linear-gradient(180deg, rgba(16,42,68,0.96), rgba(11,28,46,0.96))`.
- Border `1px solid rgba(255,255,255,0.10)`.
- Shadow `0 22px 60px rgba(0,0,0,0.5), 0 -2px 0 rgba(255,255,255,0.05) inset`.
- Entrance: `qr-pop` — 0.5s, opacity 0→1 + scale 0.92→1 (from the translate-centered origin),
  easing `cubic-bezier(0.4,0,0.2,1)`.

#### Components (top → bottom)

**1. Status label** (centered row)
- Phosphor-bold `check` icon, 14px, color `#f7b572`.
- Text **"QUIZ COMPLETE"** — Archivo 600, 11px, letter-spacing 0.22em, UPPERCASE, color `#7e93a8`. 8px gap.

**2. Score ring** (148 × 148px, centered, 18px top margin)
- Soft amber glow behind: radial `rgba(245,158,75,0.22)→transparent`, pulsing (`qr-glow`, 3.5s ease-in-out infinite, opacity 0.45↔0.8).
- SVG, rotated −90° so the arc starts at 12 o'clock:
  - **Track circle:** cx/cy 74, **r 62**, `fill:none`, stroke `rgba(255,255,255,0.08)`, stroke-width 10.
  - **Progress arc:** same geometry, stroke = linear-gradient `#ffd9a8 → #f59440` (defined as `<linearGradient>`), stroke-width 10, `stroke-linecap:round`.
    - `stroke-dasharray = 389.56` (= 2π·62, the full circumference).
    - `stroke-dashoffset = circumference × (1 − ratio)` where `ratio = score / total`. Offset 0 = full ring; offset = circumference = empty.
- **Center content** (absolutely centered):
  - Score number: Fredoka 600, letter-spacing −0.02em, color `#eef2f6`. The **score** renders at **46px**; the **`/total`** suffix at **22px**, color `#7e93a8`. (e.g. big `7` + smaller `/10`.)
  - Caption **"CORRECT"** — Archivo 600, 9.5px, letter-spacing 0.18em, UPPERCASE, color `#5c708a`, 5px top margin.

**3. Headline** (centered, 16px top margin)
- Fredoka 600, 21px, letter-spacing −0.01em, color `#eef2f6`.
- Text is **derived from the score ratio** (see State / logic below).

**4. Meta line** (centered, 5px top margin)
- Archivo 500, 12px, letter-spacing 0.04em, color `#7e93a8`.
- Format: `"<Quiz name>  ·  <Scope label>"` — e.g. `Find the country · Whole globe`. (Ties to the
  quiz-mode picker's mode + scope selection.)

**5. Time pill** (18px top margin)
- Row: `display:flex; align-items:center; gap:10px; padding:12px 16px; border-radius:14px`.
- Background `rgba(6,18,31,0.55)`, border `1px solid rgba(255,255,255,0.08)`.
- Phosphor `clock` icon, 19px, color `#f7b572`.
- Label **"TIME"** — Archivo 600, 10px, letter-spacing 0.18em, UPPERCASE, color `#5c708a`.
- Value (pushed right with `margin-left:auto`): Fredoka 500, 17px, letter-spacing −0.01em, color `#eef2f6`.
- **Value format: `"n min m.d seconds"`** — minutes as integer, seconds to **one decimal place**. e.g. `2 min 14.3 seconds`. (See helper below.)

**6. Primary action — "Play again"** (18px top margin)
- Full-width pill: padding 13px, `border-radius:999px`.
- Background `linear-gradient(180deg,#f7a857,#f59440)`, text color `#311a06`, Fredoka 600, 15px.
- Shadow `0 8px 22px rgba(245,158,75,0.34)`. Phosphor-bold `arrow-clockwise` icon (16px) + label, 9px gap.
- Hover: `filter:brightness(1.04); transform:translateY(-1px)`. Active: `transform:translateY(0); filter:brightness(.97)`.

**7. Secondary actions** (row, 11px top margin, `gap:10px`, two equal `flex:1` pills)
- Each: padding 11px, `border-radius:999px`, transparent background, border `1px solid rgba(255,255,255,0.12)`, color `#9fb2c6`, Archivo 600, 13.5px, icon 16px + label, 8px gap.
- Hover: background `rgba(255,255,255,0.04)`, color `#cdd8e3`.
- Left: Phosphor `share-network` + **"Share"**. Right: Phosphor `globe-hemisphere-west` + **"Globe"** (back to globe).

#### Staggered entrance
All inner blocks fade up via `qr-fade` (0.5s, opacity 0→1 + translateY 8px→0) with delays:
label .05s, ring .1s, headline .15s, meta .18s, time .22s, primary .26s, secondary .3s.

---

## Interactions & Behavior

- **Score count-up animation:** on mount (and whenever "Play again" is pressed), the score ring
  fills from empty and the center number counts up from `0` to the final score over **950ms**,
  using **easeOutCubic** (`1 − (1−p)³`). A single normalized progress value `t` (0→1) drives both:
  - displayed number = `round(score × t)`
  - ring dashoffset = `circumference × (1 − ratio × t)`
- **Play again:** replays the count-up animation. In the real app, this should also restart the
  quiz (same mode + scope).
- **Share:** opens the platform share sheet with the result (placeholder in prototype).
- **Globe:** dismisses the modal and returns to the globe view (placeholder in prototype).
- Hover/active states as specified per component above.

---

## State Management

**Inputs (props):**
- `score: number` — correct answers (default 7).
- `total: number` — total questions (default 10).
- `seconds: number` — elapsed time in seconds, may be fractional (default 134.3).
- `quizName: string` — e.g. `"Find the country"`.
- `scopeLabel: string` — e.g. `"Whole globe"` or a continent name.

**Internal state:**
- `t: number` (0→1) — animation progress, drives the count-up + ring fill. Reset to 0 and
  re-tweened on mount and on "Play again".

**Derived values:**
- `ratio = total > 0 ? score / total : 0`.
- `headline` from ratio:
  - `=== 1` → "Perfect run!"
  - `>= 0.8` → "Brilliant work"
  - `>= 0.6` → "Nicely done"
  - `>= 0.4` → "Good effort"
  - else → "Keep exploring"
- `metaLine = quizName + "  ·  " + scopeLabel`.
- `timeStr = formatTime(seconds)`.

**Time formatting helper (exact logic):**
```js
function formatTime(totalSeconds) {
  const m = Math.floor(totalSeconds / 60);
  const s = (totalSeconds - m * 60).toFixed(1); // one decimal place
  return `${m} min ${s} seconds`;
}
// 134.3 -> "2 min 14.3 seconds";  47.6 -> "0 min 47.6 seconds"
```
Note: the format always shows the minutes segment (so sub-minute times read `0 min ...`).
Confirm with product whether sub-minute times should drop the `0 min` — current spec keeps it.

---

## Design Tokens
From `tokens/` (link `styles.css`). Values used here:

**Colors**
- Navy: `#06121f`, `#0a1c30`, `#102a44`; modal gradient uses `rgba(16,42,68,.96)→rgba(11,28,46,.96)`.
- Amber: `#ffd9a8`, `#f59e4b`, `#f59440`, `#f7a857`; icon tint `#f7b572`; ring gradient `#ffd9a8→#f59440`.
- Text: `#eef2f6` (high), `#7e93a8` (mid), `#5c708a` (low); secondary button text `#9fb2c6` / hover `#cdd8e3`.
- Lines: `rgba(255,255,255,0.08–0.12)`. Glow: `rgba(245,158,75,0.22)`.

**Typography**
- `--font-display: "Fredoka"` (score number, headline, time value, primary button) — weights 500/600.
- `--font-ui: "Archivo"` (labels, captions, secondary buttons) — weights 500/600.
- Uppercase labels use wide tracking (0.18–0.22em). Headline is sentence case (Fredoka).

**Radius:** pill `999px` (buttons), `26px` (modal), `14px` (time pill). **Stroke:** ring width 10, r 62.

**Shadow:** modal `0 22px 60px rgba(0,0,0,.5)` + inset hairline; primary button `0 8px 22px rgba(245,158,75,.34)`.

**Motion:** easing `cubic-bezier(0.4,0,0.2,1)`. Count-up 950ms easeOutCubic. Entrance pop 0.5s,
staggered fades 0.5s, glow loop 3.5s. Gentle, never bouncy.

---

## Assets
- `assets/globe.png` — brand globe mark (the prototype backdrop; the real app shows the live globe).
- **Icons:** [Phosphor](https://phosphoricons.com/) (MIT). Weights: `regular` + `bold`. Icons used:
  `check` (bold), `clock`, `arrow-clockwise` (bold), `share-network`, `globe-hemisphere-west`.
  Use the codebase's existing Phosphor integration if present.
- **Fonts:** Fredoka + Archivo via Google Fonts (`tokens/fonts.css`). No font binaries bundled.

## Files
- `Quiz Results.dc.html` — the design prototype (reference only; runs on `support.js`, do not ship).
- `styles.css` + `tokens/*.css` — the real design system (source of truth for tokens).
- `readme.md` — the full Terragotcha design-system readme (voice, brand, iconography rules).
- `assets/globe.png` — globe mark.
