# Handoff: Globe Quiz Screen ("Which country is highlighted?")

## Overview
The in-quiz **question screen that overlays the live 3D globe**. The three.js globe highlights
a country; the player picks its name from **6** options. This is the responsive layout work:
the quiz UI must coexist with a full-screen (mobile) / large (desktop) globe **without covering
it** — so the panel sits below the globe's center and is tightly size-constrained.

This restyles the old screen (see original screenshot) to match the rest of the app, fixes the
prompt copy, and specifies **two responsive layouts**.

## About the Design Files
The files in this bundle are **design references created in HTML** — a prototype of the intended
look and behavior, **not production code to copy directly**. `Quiz Globe.dc.html` is a "Design
Component" that runs in a bespoke preview runtime (`support.js`); do **not** ship `support.js`
or the `.dc.html` format.

Recreate this in the Terragotcha app's existing environment using its established patterns and
component libraries. `styles.css` + `tokens/` **are** the real design system (source of truth
for colors, type, effects; map onto existing codebase tokens if equivalents exist).

> **The globe is a placeholder.** The prototype draws the brand globe image (`assets/globe.png`)
> with a clearly-marked "three.js globe · rendered in-app" tag and a pulsing white blob standing
> in for the highlighted country. In the app, **the real three.js globe renders behind/around
> this UI and owns the country highlight** — do not build the globe from this asset. The quiz
> panel is the deliverable; it floats over the globe.

> **The prototype shows two frames side by side** (Mobile + Desktop) on a pannable canvas for
> review. These are **one responsive screen**, not two screens. The device/desktop frames
> (390 × 800 and 1180 × 760, with corner radii) are presentation only — build full-bleed and
> drive the breakpoint off the viewport.

## Fidelity
**High-fidelity (hifi).** Exact colors, type, spacing, radii, and interactions are specified
below and present in the prototype.

---

## Responsive behavior (the core of this task)

The globe is always full-bleed behind everything. The quiz panel placement changes by breakpoint:

### Mobile (narrow / portrait)
- Globe fills the screen; its visual center sits in the upper ~⅔.
- The quiz panel **hugs the bottom edge**, full width, with rounded **top** corners only
  (`26px 26px 0 0`).
- **Hard constraint: the panel is capped at `max-height: 33vh`** so it never covers the globe's
  center (where the highlighted country appears). In the prototype it renders at ~27% of screen
  height — keep it comfortably under the 33% ceiling. Everything below is tuned to fit that budget.

### Desktop (wide / landscape)
- Globe is large, biased toward center-left.
- The quiz panel is a **floating card in the bottom-right quadrant** (`right:30px; bottom:30px`,
  width ~430px, fully rounded `24px`), leaving the globe and its highlight clearly visible.
- A standalone **close button** sits at the top-right of the viewport (separate from the card).

Pick the breakpoint where the globe stops being full-bleed and gains side margin (suggest the
usual tablet boundary, ~768–900px); confirm with the existing app's breakpoints.

---

## Shared content (both layouts)
Top → bottom inside the panel:
1. **Header** — question counter + score + timer + close (compact on mobile, see below).
2. **Progress bar** — thin track, amber gradient fill = `qNum/10` wide.
3. **Prompt** — two lines (see typographic emphasis below).
4. **Answer options** — 6 country names in a grid; single-select, locks on tap.

### Prompt typography (important detail)
The prompt is **two stacked lines with deliberately reversed emphasis**:
- **Line 1 — "Which country"** is the **prominent** line: **Fredoka 600**, large, color `#eef2f6`
  (mobile 18px, desktop 27px), letter-spacing −0.01em.
- **Line 2 — "is highlighted on the globe"** is the **quiet** line: **Archivo 600**, small,
  **UPPERCASE**, letter-spacing ~0.18–0.2em, color `#5c708a` (mobile 9px, desktop 10.5px).

(The old screen's prompt read "Which country does this flag belong to?" — wrong copy for a
globe-highlight question. Corrected here.)

### Answer options
- **6 options**, single correct (the highlighted country) + 5 distractors. In the prototype the
  answer is **Honduras**, distractors are its Central-American neighbors (Nicaragua, Belize,
  El Salvador, Guatemala, Costa Rica). Good distractor selection (regional neighbors) is part of
  the quiz design — coordinate with product/content.
- **Mobile grid: 3 columns × 2 rows.** Compact cells: centered label (Archivo 600, ~12px,
  ellipsis on overflow), padding `11px 7px`, radius 11px. The result icon is a **small corner
  badge** (absolute, top-right) so it doesn't eat the narrow cell width.
- **Desktop grid: 2 columns × 3 rows.** Roomier cells: left-aligned label (Archivo 600, ~14.5px)
  with an **inline** trailing result icon, padding `13px 15px`, radius 13px.

### Header — compact vs roomy
- **Mobile (must fit the 33vh budget):** a **single inline row** — `Q{n}/10` label, then score
  (`check-circle` icon + `3/3`), then timer (`clock` icon + `0:04`) as inline Fredoka text, then
  the close button pushed to the right (`margin-left:auto`, 28px circle). No large chip boxes.
- **Desktop:** question counter top-left; a small timer pill top-right; a full-width **Score**
  chip row below it (icon + "SCORE" label + `3/3` value). More breathing room.

---

## Interaction & States

Single-select, **locks on first tap** (one answer per question). On tap, reveal the outcome:
- **Correct option** (always revealed): bg `rgba(46,160,103,0.16)`, border `rgba(64,196,128,0.6)`,
  text `#bff0d2`, icon Phosphor-bold `check` `#6fe3a0`.
- **Your wrong pick:** bg `rgba(196,60,60,0.16)`, border `rgba(228,90,90,0.6)`, text `#f3c4c4`,
  icon Phosphor-bold `x` `#f08a8a`.
- **Other options:** dimmed text `#6f8298`.
- Idle option: bg `rgba(255,255,255,0.025)`, border `rgba(255,255,255,0.10)`, text `#dfe7ef`.

Score increments on a correct answer; the `/n` denominator increments on every answer.
Transitions: `all .18s cubic-bezier(0.4,0,0.2,1)`.

> **Semantic green/red are new.** The Terragotcha system is single-accent (amber) with no defined
> success/error colors. The greens/reds above are introduced for quiz feedback (shared with the
> other quiz screens) — **promote them to named tokens (`--correct`, `--wrong`) and confirm with
> design.**

### Globe placeholder & highlight
- Placeholder tag: a dashed-border pill, `three.js globe · rendered in-app`, with a Phosphor
  `cube` icon — remove entirely in production.
- Highlight stand-in: a white rounded blob with a white + amber glow, pulsing
  (`qg-hl`, 2.4s ease-in-out). In production the **three.js globe** highlights the actual country
  geometry — this prototype marker is not pinned to a real shape.
- The placeholder globe image slowly rotates (`qg-spin`, 90s linear) — purely indicative.

### Entrance / motion
- Easing throughout `cubic-bezier(0.4,0,0.2,1)` — gentle, never bouncy (per brand).
- `qg-fade` (translateY + opacity) for panel content; `qg-spin` globe rotation; `qg-hl` highlight pulse.

---

## State Management
**Inputs (from quiz engine):**
- `qNum` (1-based) → counter label + progress fill.
- `score`, `answered` → the score readout.
- Timer string `m:ss` (prototype shows static `0:04`; wire to the real countdown).
- The highlighted/target country + an array of **6** country-name options (1 correct + 5 distractors, shuffled).

**Internal state:** selected answer (`null` until tap) → derives locked/colored states. Reset per question.
**Contract on tap:** record choice, compare to target, update score/answered, reveal states, advance (timing is a product decision).

---

## Design Tokens (from `tokens/`, via `styles.css`)
**Colors**
- Navy gradient `#102a44 → #0a1c30 → #06121f`; panel fills `rgba(13,33,54,.86–.9) → rgba(8,21,35,.94–.95)` with `backdrop-filter: blur(18–20px)`; chip fills `rgba(6,18,31,.5)`.
- Amber `#ffd9a8`, `#f59440`, `#f7b572` (icon tint); progress + highlight glow gradients use the amber family.
- Text `#eef2f6` (high), `#dfe7ef` (option label), `#7e93a8` (mid), `#5c708a` (low), `#6f8298` (dimmed).
- Correct/Wrong feedback greens/reds — see note above (new semantic tokens).

**Typography** — `--font-display: "Fredoka"` (prompt line 1, stat values, weight 600); `--font-ui: "Archivo"` (labels, options, weight 600). Uppercase labels use wide tracking (0.16–0.2em). Prompt line 1 is sentence case.

**Radius** — mobile panel `26px 26px 0 0`; desktop card `24px`; options `11px` (mobile) / `13px` (desktop); progress + close `999px`. **Shadows** — mobile panel `0 -14px 40px rgba(0,0,0,.4)` (casts upward); desktop card `0 22px 60px rgba(0,0,0,.5)` + inset hairline.

**Motion** — easing `cubic-bezier(0.4,0,0.2,1)`; state transitions 0.18s; highlight pulse 2.4s; globe rotation 90s.

**Layout constants** — mobile panel `max-height: 33vh` (hard cap); mobile grid `repeat(3,1fr)` gap 8px; desktop card width ~430px at `right:30px; bottom:30px`, desktop grid 2-col gap 11px.

---

## Assets
- **Icons:** [Phosphor](https://phosphoricons.com/) (MIT), weights `regular` / `bold` / `fill`. Used: `x`, `clock`, `cube`, `check-circle` (fill), `check` (bold), `x` (bold).
- **Fonts:** Fredoka + Archivo via Google Fonts (`tokens/fonts.css`).
- `assets/globe.png` — brand globe, used **only** as the prototype's placeholder (do not ship as the in-app globe).

## Files
- `Quiz Globe.dc.html` — the prototype (reference only; runs on `support.js`, do not ship). Contains BOTH responsive layouts side by side.
- `styles.css` + `tokens/*.css` — the real design system.
- `readme.md` — the full Terragotcha design-system readme (voice, brand, iconography).
- `assets/globe.png` — globe mark (placeholder use only).
