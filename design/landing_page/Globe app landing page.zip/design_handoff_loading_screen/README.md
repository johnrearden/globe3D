# Handoff: Terragotcha Loading Screen

## Overview
A full-screen loading/splash overlay for **Terragotcha**, a geography quiz app. It shows
while the 3D (three.js) globe renders, drawing the user's attention with the logo, a
globe mark, a tagline, and an indeterminate progress indicator. The overlay should cover
the screen on launch and fade/dismiss once the globe is ready.

## About the Design Files
The files in this bundle are **design references created in HTML** — a prototype showing
the intended look and behavior, **not** production code to copy directly. The task is to
**recreate this design in the app's existing environment** (the three.js / web front-end
that already renders the globe), using its established patterns. If the splash needs to
live in a different layer (e.g. a React overlay or plain DOM mounted before three.js
initializes), implement it idiomatically there.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, and motion are specified below.
Recreate it pixel-accurately. The one judgment call is layout scaling: values below are
authored for a ~392px-wide portrait viewport — adapt to the real device width
proportionally (the lockup is horizontally centered; the bar sits a fixed distance from
the bottom).

## Screens / Views

### Loading Screen (single view)
- **Purpose**: Hold attention and signal progress while the globe loads.
- **Layout**: Full-viewport container, dark navy background. Two stacked groups:
  1. **Top lockup** — vertically stacked, horizontally centered, positioned ~118px from
     the top (≈15% of an 800px-tall frame): globe image → wordmark → tagline.
  2. **Bottom indicator** — horizontally centered, fixed ~72px from the bottom: progress
     bar → status label.
- **Components**:
  - **Globe mark**
    - Photographic globe (PNG, see Assets), 170×170px, centered.
    - Sits over a soft amber radial glow: `radial-gradient(circle, rgba(245,158,75,.18), rgba(245,158,75,0) 66%)`, inset −6px, gently pulsing (see Interactions).
    - The PNG already has a feathered transparent edge so it blends into the navy bg — do not add a hard circular border.
  - **Wordmark** — "Terragotcha"
    - Font: **Fredoka**, "Terra" weight 400, "gotcha" weight 600 (subtle weight contrast).
    - Size 38px, letter-spacing −0.01em, margin-top 22px above tagline group.
    - Fill: a moving light gradient (shimmer) clipped to the text:
      `linear-gradient(100deg,#dbe4ee 32%,#ffffff 45%,#ffd9a8 50%,#ffffff 55%,#dbe4ee 68%)`,
      `background-size:240% 100%`, `-webkit-background-clip:text; color:transparent`.
    - Static fallback color (no shimmer): `#eef2f6`.
  - **Tagline** — "Learn geography through quizzes"
    - Font: **Archivo** 500, 12.5px, UPPERCASE, letter-spacing 0.22em, color `#7e93a8`, margin-top 14px.
  - **Progress bar**
    - Track: 148×3px, radius 3px, `background:rgba(255,255,255,.09)`, `overflow:hidden`.
    - Indicator: 38% wide, full height, radius 3px,
      `background:linear-gradient(90deg, rgba(245,158,75,0), #f59e4b 50%, rgba(245,158,75,0))`,
      sweeping left→right (indeterminate).
  - **Status label** — "Loading the world"
    - Font: **Archivo**, 10.5px, UPPERCASE, letter-spacing 0.2em, color `#5c708a`, 16px below the bar.

## Interactions & Behavior
- **Entrance**: each top element fades up — `opacity 0→1` + `translateY(10px)→0`, 0.8s ease.
  Stagger: globe 0s, wordmark 0.1s, tagline 0.2s.
- **Wordmark shimmer**: gradient `background-position` animates from `160% 0` → `-60% 0`,
  4s, linear, infinite. (Gentle, continuous.)
- **Globe glow pulse**: opacity `0.55 → 0.9 → 0.55`, 3.5s ease-in-out, infinite.
- **Progress bar**: indicator `left: -38% → 100%`, 1.5s ease-in-out, infinite (indeterminate;
  it does not represent real %). If real progress is available, switch to setting the
  indicator width 0→100% instead.
- **Dismiss**: when the globe is ready, fade the whole overlay out (suggest 300–400ms) and
  remove from the DOM / unmount.

## State Management
- `isLoading: boolean` — controls overlay visibility. Set true on launch, false when the
  globe scene + textures finish loading. The overlay's only job is to listen for that
  "ready" signal and dismiss.
- No other state required for the static design. (If wiring real progress, add `progress: 0–1`.)

## Design Tokens
Colors
- Background navy (solid): `#0a1c30`
- Background gradient (frame): `radial-gradient(120% 80% at 50% 8%, #102a44 0%, #0a1c30 42%, #06121f 100%)`
- Amber accent: `#f59e4b`  (glow tint `rgba(245,158,75,…)`)
- Warm amber light (shimmer stop): `#ffd9a8`
- Wordmark static / light text: `#eef2f6` · shimmer stops `#dbe4ee` / `#ffffff`
- Tagline text: `#7e93a8`
- Status label text: `#5c708a`
- Track fill: `rgba(255,255,255,.09)`

Typography
- Display / wordmark: **Fredoka** (Google Fonts), weights 400 & 600
- UI / tagline / labels: **Archivo** (Google Fonts), weights 400/500/600

Spacing & sizing (portrait reference)
- Globe mark: 170px · glow inset −6px
- Wordmark 38px / −0.01em · tagline 12.5px / 0.22em · label 10.5px / 0.2em
- Top lockup offset: 118px from top · bar offset: 72px from bottom
- Progress track: 148×3px, radius 3 · indicator 38% width

Motion
- Fade-up 0.8s ease (stagger 0/0.1/0.2s) · shimmer 4s linear · glow 3.5s ease-in-out · bar 1.5s ease-in-out

## Assets
- `assets/globe.png` — the photographic globe mark (612×612 PNG, transparent feathered
  edge). Derived from a screenshot of the app's own three.js render, masked to a soft
  circle. **At runtime you may prefer to skip this PNG and reuse the live three.js globe**
  (rendered small/blurred behind the lockup) — but the PNG is provided as the design intent
  and a safe fallback before the WebGL context is ready.

## Files
- `Terragotcha Loading.dc.html` — the HTML prototype (open in a browser to see it live).
  Note: it also renders three logo-lockup variations at the top of the page (wordmark only,
  mark+wordmark, stacked) for reference — the **stacked** version is the one used in the
  loading screen. The lockup variations and the gray canvas around the phone frame are
  presentation scaffolding, not part of the shipped overlay.
