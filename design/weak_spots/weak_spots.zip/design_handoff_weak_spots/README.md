# Handoff: "Weak spots" Overlay

## Overview
A small **heads-up overlay** docked in the **top-right corner** of the globe screen. It lists the
countries the player gets wrong most often ("weak spots") so they're always glanceable during
play. It is **chromeless** — no panel, card, or background — the title + list float directly over
the live 3D globe.

## About the Design Files
The files in this bundle are **design references created in HTML** — a prototype of the intended
look and behavior, **not production code to copy directly**. `Weak Spots.dc.html` is a "Design
Component" that runs in a bespoke preview runtime (`support.js`); do **not** ship `support.js` or
the `.dc.html` format.

Recreate this in the Terragotcha app's existing environment using its established patterns and
component libraries. `styles.css` + `tokens/` **are** the real design system (source of truth for
colors, type, effects; map onto existing codebase tokens if equivalents exist).

> **The globe is context, not part of this deliverable.** The prototype draws the brand globe
> image (`assets/globe.png`) only to show the overlay reading against it. In the app the real
> three.js globe is already there — build just the overlay, positioned over it.

> **The prototype shows two frames side by side** (Mobile + Desktop) on a pannable canvas to
> demonstrate the responsive type scaling. These are the **same overlay at two breakpoints**, not
> two components. The device/desktop frames are presentation only.

## Fidelity
**High-fidelity (hifi).** Exact placement, type, sizing, and the fade behavior are specified
below and present in the prototype.

---

## Anatomy (top → bottom)

Positioned `top` / `right` in the corner (mobile `top:18px; right:14px`; desktop `top:26px;
right:30px`). No background, border, blur, or shadow on the container. A **text-shadow**
(`0 1px 4px rgba(0,0,0,.7)` on names, slightly softer on the title) carries legibility over the
busy globe — this replaces the panel.

1. **Title** — the word mark for the widget, **right-aligned** (the whole group is flush to the
   right edge, echoing the flag column):
   - Label **"WEAK SPOTS"** — Archivo 600, UPPERCASE, letter-spacing ~0.16–0.18em, color `#9fb2c6`
     (muted — deliberately *not* accentuated, so the country names read as the content).
   - A small Phosphor-fill `crosshair` icon in amber `#f7b572`, to the **right** of the label.
2. **List** — a vertically **scrollable** list of countries. Each row, right-aligned:
   - **Country name** — Archivo 500, **plain white `#f4f7fa`** (not accentuated), `text-align:right`,
     ellipsis on overflow.
   - **Miniature flag** — to the **right of the name** (the rightmost element in the row),
     `object-fit:cover`, rounded ~2–3px, hairline border `rgba(255,255,255,.16)`, small drop shadow.
   - Row is `display:flex; align-items:center; justify-content:flex-end; gap:…` so names share a
     common right edge (right-justified) and flags line up in a fixed right-hand column.

There is **no divider and no panel** — just the title, a gap, and the list.

---

## Sizing & responsiveness (a core requirement)

**The overlay must take up no more than 30% of the screen width on mobile.** In the prototype the
mobile overlay renders at **~25% (96px of a 390px screen)**. Implement with
`width: fit-content; max-width: 30vw` (the prototype uses `max-width:30%` inside its fixed frame).

**Type is larger on larger screens.** The prototype demonstrates this with two fixed breakpoints;
implement with `clamp()` or media/container queries.

| Token | Mobile | Desktop |
|---|---|---|
| Country name font | 11px | 15px |
| Title label font | 9px | 11.5px |
| Title icon | 11px | 15px |
| Flag size | 19 × 13 | 27 × 18 |
| Row height | 34px | 44px |
| Row gap (name↔flag) | 7px | 11px |
| List viewport height | 170px (5 × 34) | 220px (5 × 44) |
| Container max-width | 30vw (~96px) | ~240px |

Use these as the two anchor points; interpolate between them as you see fit (a `clamp()` on font
size keyed to viewport width is the simplest faithful implementation). Desktop is **not** held to
the 30% rule — only mobile is.

---

## The fade behavior (the defining detail)

**Five countries are visible by default.** The list fades out at the bottom: **fully opaque
through the 3rd row, then fading from the top of the 4th row down to fully transparent at the
bottom of the 5th row.**

Implement as a **CSS mask on the scroll viewport** (NOT a per-item opacity, NOT an overlay
gradient):

```css
.weakspots-list {
  height: calc(5 * var(--row-height));            /* exactly 5 rows tall */
  overflow-y: auto;
  -webkit-mask-image: linear-gradient(to bottom, #000 0%, #000 60%, transparent 100%);
          mask-image: linear-gradient(to bottom, #000 0%, #000 60%, transparent 100%);
}
```

Why `60%`: with 5 rows visible, the top of the 4th row is at `3/5 = 60%` of the viewport height;
the bottom of the 5th is at `100%`. Because the mask is anchored to the **viewport** (not the
content), **the fade stays pinned to the bottom while the list scrolls** — exactly the required
behavior. The list keeps scrolling under a fixed fade.

> **If you change the visible count or row height, recompute the stop:** fade start % =
> `(visibleCount − 2) / visibleCount × 100`. (5 → 60%, 6 → 66.7%, etc.) Keep the viewport height =
> `visibleCount × rowHeight`.

Hide the scrollbar (`scrollbar-width:none` + `::-webkit-scrollbar{display:none}`) so only the
content and fade are visible.

---

## Data & State

- The list is driven by the player's **wrong-answer tally** — countries ranked by most wrong
  answers, descending. The prototype uses sample data (Kyrgyzstan, Suriname, Eswatini, Djibouti,
  Turkmenistan, Brunei, Comoros, Vanuatu, Lesotho) with 9 entries so the scroll/fade is visible.
- Each entry needs a country **name** + a **flag** (or ISO 3166-1 alpha-2 code to resolve one).
- The overlay is **display-only** (no selection/interaction in this spec). It should update as the
  tally changes between questions/sessions.
- Consider an **empty state** (no weak spots yet) — not designed here; confirm with product.

### Flag images
The prototype loads flags from **flagcdn.com**: `https://flagcdn.com/w80/{iso2}.png` (small raster
for the mini size). **Confirm the production flag asset pipeline** (bundle your own set or a
licensed CDN); this is shared with the quiz screens.

---

## Design Tokens (from `tokens/`, via `styles.css`)
**Colors**
- Country name: plain white `#f4f7fa` (intentionally not the amber accent).
- Title label: `#9fb2c6` (muted, ~`--text-mid`); title icon: amber `#f7b572`.
- Flag border `rgba(255,255,255,.16)`; text-shadow `rgba(0,0,0,.6–.7)` for legibility over the globe.

**Typography** — `--font-ui: "Archivo"`: names weight 500, title weight 600 UPPERCASE with wide
tracking (per the brand's "map label" caps system). No Fredoka here.

**Motion** — entrance `ws-fade` (0.5s, opacity + small translateY), easing `cubic-bezier(0.4,0,0.2,1)`,
gentle. (The globe rotation in the prototype is just backdrop ambiance.)

**Radius** — flag corners 2–3px. No container radius (no container).

---

## Assets
- **Icons:** [Phosphor](https://phosphoricons.com/) (MIT), `fill` weight — `crosshair`. Use the
  codebase's existing Phosphor integration if present.
- **Fonts:** Archivo via Google Fonts (`tokens/fonts.css`).
- **Flags:** flagcdn.com `w80` PNGs (placeholder — confirm production source).
- `assets/globe.png` — brand globe, used **only** as the prototype backdrop (the real globe is the app's three.js scene).

## Files
- `Weak Spots.dc.html` — the prototype (reference only; runs on `support.js`, do not ship). Shows mobile + desktop side by side.
- `styles.css` + `tokens/*.css` — the real design system.
- `readme.md` — the full Terragotcha design-system readme (voice, brand, iconography).
- `assets/globe.png` — globe mark (backdrop only).
