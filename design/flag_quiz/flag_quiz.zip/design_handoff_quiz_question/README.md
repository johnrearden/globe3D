# Handoff: Quiz Question Screens (Name the country / Identify the flag)

## Overview
The in-quiz **question screen** for Terragotcha, in **two directions**:

1. **Name the country** — show a flag, the player picks the matching **country name** from **6** options.
2. **Identify the flag** (reverse) — show a **country name**, the player picks the matching **flag** from **6** options.

This replaces the old 4-option question UI (see the original screenshot) — option count is now **6** — and restyles it to match the rest of the app (loading screen, quiz-mode picker, results modal).

## About the Design Files
The files in this bundle are **design references created in HTML** — a prototype showing the
intended look and behavior, **not production code to copy directly**. `Quiz Question.dc.html`
is a "Design Component" that runs in a bespoke preview runtime (`support.js`); do **not** ship
`support.js` or the `.dc.html` format.

Your task is to **recreate this design in the Terragotcha app's existing environment** using its
established patterns and component libraries. The app is a mobile geography quiz built on a
three.js 3D globe; this is the full-screen quiz view. If the relevant part of the codebase has
no established UI framework yet, choose the most appropriate one and implement there.

`styles.css` + `tokens/` **are** the real design system and are the source of truth for colors,
type, and effects (or map them onto the codebase's existing tokens if equivalents exist).

> **Canvas note:** the prototype shows both directions **side by side** for review (it uses a
> pannable canvas with two device frames). In the app these are **one screen with two question
> types** — not two screens. The device frames (392 × 788, 40px radius) are presentation only;
> build the screen full-bleed.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, radii, and interactions are all
specified below and present in the prototype. Recreate pixel-perfectly using the codebase's
existing libraries. Exact hex/px values are given throughout.

---

## Shared layout (both question types)

App canvas: deep navy brand gradient
`radial-gradient(120% 80% at 50% 6%, #102a44 0%, #0a1c30 44%, #06121f 100%)`.

Content is inset 20px left/right. Top → bottom:

1. **Top bar** (`top:20px`, full width inset):
   - **Progress label** (left): `"QUESTION n OF 10"` — Archivo 600, 11px, letter-spacing 0.2em, UPPERCASE, color `#7e93a8`.
   - **Close button** (right): 34 × 34px circle, background `rgba(10,20,34,0.7)`, border `1px solid rgba(255,255,255,0.1)`, Phosphor `x` icon 15px color `#a9bccf`. Hover → background `rgba(10,20,34,0.95)`, icon `#eef2f6`.
2. **Stat chips row** (two equal `flex:1` chips, `gap:10px`):
   - Each chip: padding `11px 14px`, `border-radius:14px`, background `rgba(6,18,31,0.55)`, border `1px solid rgba(255,255,255,0.08)`.
   - **Score chip:** Phosphor-fill `check-circle` (18px, `#f7b572`) + label `"SCORE"` (Archivo 600, 9.5px, 0.16em, UPPERCASE, `#5c708a`) + value pushed right (`margin-left:auto`): Fredoka 600, 16px `#eef2f6` for the score, with `/answered` at 12px `#7e93a8`.
   - **Time chip:** Phosphor `clock` (18px, `#f7b572`) + label `"TIME"` + value `"2:45"` (Fredoka 600, 16px, `#eef2f6`). Timer format `m:ss`.
3. **Progress bar** (`margin-top:12px`): 5px tall, `border-radius:999px`, track `rgba(255,255,255,0.08)`; fill = `(qNum/10)` wide, `linear-gradient(90deg,#ffd9a8,#f59440)`.
4. **Question prompt** (centered, `margin-top:22px`):
   - Eyebrow line — Archivo 600, ~10.5px, letter-spacing 0.2em, UPPERCASE, color `#5c708a`.
   - Main line — Fredoka 600, color `#eef2f6`, letter-spacing −0.01em.
   - **Name the country:** eyebrow `"WHICH COUNTRY"`, main `"does this flag belong to?"` (21px).
   - **Identify the flag:** eyebrow `"WHICH FLAG BELONGS TO"`, main `"{Country}?"` (26px) — the `?` is tinted amber `#f7b572`.
5. **Stage / answer area** — differs per type (below).

---

## Type A — Name the country

**Flag stage** (`margin-top:18px`): a rounded panel, `border-radius:18px`, background
`rgba(6,18,31,0.5)`, border `1px solid rgba(255,255,255,0.08)`, padding `26px 20px`, centered.
- A soft amber radial glow fills the panel (`radial-gradient(circle at 50% 50%, rgba(245,158,75,0.14), transparent 70%)`), pulsing (`qq-glow`, 3.5s ease-in-out infinite, opacity 0.4↔0.75).
- The flag image: ~208px wide, `border-radius:6px`, shadow `0 10px 26px rgba(0,0,0,0.5)`, scales in (`qq-flagin`, opacity+scale 0.96→1).

**Answer grid** (`margin-top:18px`): CSS grid, **2 columns × 3 rows = 6 options**, `gap:10px`.
- Option (idle): `display:flex; align-items:center; gap:8px; padding:14px 16px; border-radius:14px`, background `rgba(255,255,255,0.025)`, border `1px solid rgba(255,255,255,0.10)`, color `#dfe7ef`, Archivo 600, 14px. Label truncates with ellipsis (`white-space:nowrap; overflow:hidden; text-overflow:ellipsis`).
- An optional result icon sits at the right end (check / x).

---

## Type B — Identify the flag

**No flag stage** — the country name in the prompt is the question.

**Flag answer grid** (`margin-top:24px`): CSS grid, **2 columns × 3 rows = 6 options**, `gap:12px`.
- Option (idle): `position:relative; padding:8px; border-radius:14px`, background `rgba(6,18,31,0.5)`, **border `2px solid rgba(255,255,255,0.12)`**.
- Inside: the flag `<img>` at `width:100%`, `border-radius:6px`, shadow `0 4px 12px rgba(0,0,0,0.4)`.
- A circular result badge can appear at the top-right corner (see states).

---

## Interactions & States

The round is **single-select and locks on first tap** (one answer per question). Tapping an
option commits it and reveals the outcome; further taps are ignored until the next question.

**Type A (country-name buttons) after selection:**
- **Correct option** (always revealed, whether or not it was the pick): background `rgba(46,160,103,0.16)`, border `rgba(64,196,128,0.6)`, text `#bff0d2`, trailing Phosphor-bold `check` icon `#6fe3a0`.
- **Your wrong pick:** background `rgba(196,60,60,0.16)`, border `rgba(228,90,90,0.6)`, text `#f3c4c4`, trailing Phosphor-bold `x` icon `#f08a8a`.
- **Other options:** dim text `#6f8298`, no border/background change.

**Type B (flag tiles) after selection:**
- **Correct tile:** border `rgba(64,196,128,0.85)`, plus glow ring `box-shadow:0 0 0 3px rgba(64,196,128,0.25)`; corner badge (top-right, −9px offset, 26px circle, background `#2ea067`, white Phosphor-bold `check`, 2px `#0a1c30` ring).
- **Your wrong pick:** border `rgba(228,90,90,0.85)`, ring `0 0 0 3px rgba(228,90,90,0.22)`; corner badge background `#c43c3c`, white Phosphor-bold `x`.
- **Other tiles:** `opacity:0.42`.

**Score behavior:** on a correct answer, `score` increments; `answered` (the `/n` denominator)
increments on every answer. Both reflect immediately in the Score chip.

All state transitions use `transition:all .18s cubic-bezier(0.4,0,0.2,1)`.

### Entrance animations
- `qq-fade` (0.5s, opacity 0→1 + translateY 8px→0) staggered: chips .04s, progress .08s, prompt .12s, stage .16s, grid .2–.22s.
- `qq-glow` (3.5s loop) on the flag-stage glow; `qq-flagin` on the flag image.
- Easing throughout: `cubic-bezier(0.4,0,0.2,1)` — gentle, never bouncy.

---

## State Management

**Per-question inputs (from quiz engine):**
- `qNum: number` — current question index (1-based), drives label + progress bar.
- `score: number`, `answered: number` — running tally for the Score chip.
- Timer string `m:ss` (the prototype shows a static `2:45`; wire to the real countdown).
- **Type A:** `flagUrl` (the question flag) + `target` country name + an array of **6** country-name options (1 correct + 5 distractors, shuffled).
- **Type B:** `targetCountry` name + an array of **6** flags (1 correct + 5 distractors, shuffled), each `{ code, country }`.

**Internal state:** the selected answer (`null` until the player taps), used to derive the
locked + colored states above. Reset per question.

**Selection contract:** on tap, record the choice, compare to the correct answer, update
score/answered, reveal states, then advance to the next question (timing/auto-advance is a
product decision — not specified here).

---

## Flag images

The prototype loads flags from **flagcdn.com**: `https://flagcdn.com/w320/{iso2}.png`
(e.g. `pw` = Palau). This is a placeholder source for the design — **confirm the production
flag asset pipeline** (bundle your own SVG/PNG set, or a licensed CDN). ISO 3166-1 alpha-2
lower-case codes are used.

The prototype uses **Palau** as the example (matching the source screenshot). Distractors in
Type B were chosen to be visually similar (other circle/disc flags): Laos `la`, Bangladesh `bd`,
Micronesia `fm`, Somalia `so`, Japan `jp`. Good distractor selection (visually or
geographically near the answer) is part of the quiz design — coordinate with product/content.

---

## Design Tokens
From `tokens/` (link `styles.css`). Values used here:

**Colors**
- Navy gradient: `#102a44 → #0a1c30 → #06121f`; chip/stage fills `rgba(6,18,31,0.5–0.55)`.
- Amber: `#ffd9a8`, `#f59440`, `#f7b572` (icon tint); progress gradient `#ffd9a8 → #f59440`.
- Text: `#eef2f6` (high), `#dfe7ef` (option label), `#7e93a8` (mid), `#5c708a` (low), `#6f8298` (dimmed option).
- **Correct (semantic green — NOT in base tokens, add it):** fills `rgba(46,160,103,0.16)`, border `rgba(64,196,128,0.6–0.85)`, icon `#6fe3a0`, badge `#2ea067`.
- **Wrong (semantic red — NOT in base tokens, add it):** fills `rgba(196,60,60,0.16)`, border `rgba(228,90,90,0.6–0.85)`, icon `#f08a8a`, badge `#c43c3c`.
  - *Note:* the Terragotcha system is single-accent (amber) and has no defined success/error
    colors yet. These greens/reds are introduced here for quiz feedback — **promote them to named
    semantic tokens** (`--correct`, `--wrong`) when you implement, and confirm with design.

**Typography**
- `--font-display: "Fredoka"` (prompt, stat values, target country) — weight 600.
- `--font-ui: "Archivo"` (labels, option text) — weight 600.
- Uppercase labels use wide tracking (0.16–0.2em). Prompts are sentence case (Fredoka).

**Radius:** `14px` (chips, options, tiles), `18px` (flag stage), `999px` (progress bar, close circle), `6px` (flag images). **Borders:** 1px hairlines on chips/buttons; **2px** on flag tiles (so the colored state reads clearly).

**Shadow:** flag `0 10px 26px rgba(0,0,0,.5)`; tile flag `0 4px 12px rgba(0,0,0,.4)`; device float (presentation only) `0 14px 50px rgba(0,0,0,.3)`.

**Motion:** easing `cubic-bezier(0.4,0,0.2,1)`; state transitions 0.18s; entrances 0.5s staggered; glow loop 3.5s.

---

## Assets
- **Icons:** [Phosphor](https://phosphoricons.com/) (MIT). Weights `regular`, `bold`, `fill`. Icons used: `x`, `clock`, `check-circle` (fill), `check` (bold), `x` (bold). Use the codebase's existing Phosphor integration if present.
- **Fonts:** Fredoka + Archivo via Google Fonts (`tokens/fonts.css`). No font binaries bundled.
- **Flags:** flagcdn.com `w320` PNGs (placeholder — confirm production source).

## Files
- `Quiz Question.dc.html` — the design prototype (reference only; runs on `support.js`, do not ship). Contains BOTH question types.
- `styles.css` + `tokens/*.css` — the real design system (source of truth for tokens).
- `readme.md` — the full Terragotcha design-system readme (voice, brand, iconography rules).
